#include <iostream>

using namespace std;

int main() {

    cout << "Pedro Gabriel" << endl;

    int idade;
    cout << "Digite sua idade: ";
    cin >> idade;

    for (int i = 0; i <= idade; ++i) {
      cout << i << endl;
    }

    return 0;
}
